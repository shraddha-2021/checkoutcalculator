<?php
include('database.php');
class User{
	
	    

	 public static function getProducts(){
			$db     = new Db();
			$prodlist = $db->query('SELECT * FROM products')->fetchAll(); 
			return $prodlist;
		}
		
		
		 public static function getProducts_details($prodid){
			$db     = new Db();
			$prodlist = $db->query('SELECT * FROM products WHERE id='.$prodid.'')->fetchArray(); 
			return $prodlist;
		}
		public static function getcartdetail($userid){
			$db     = new Db();
			$prodlist = $db->query('SELECT products.*,cart.* FROM cart LEFT JOIN products ON products.id=cart.prod_id WHERE cart.user_id='.$userid.'')->fetchAll(); 
			return $prodlist;
		}
		
		public static function getcartdetail_id($prod_id){
			$db     = new Db();
			$prodlist = $db->query('SELECT prod_id FROM cart WHERE prod_id='.$prod_id.'')->fetchArray(); 
			return $prodlist;
		}
		
		
		
		public static function Savecartitems($productsincart)
		{ 	
			$db     = new Db();
			
			$insert = $db->query("INSERT INTO cart(prod_id,prod_qty,user_id) VALUES ('".$productsincart['prod_id']."','".$productsincart['prod_qty']."','".$productsincart['user_id']."')");
			
			return $insert->affectedRows();
		}
	
		public static function Saveorderitems($orders)
		{ 	
			$db     = new Db();
			
			$insert = $db->query("INSERT INTO orders(prodid,prodqty,user_id,grandtotal) VALUES ('".$orders['prodid']."','".$orders['prodqty']."','".$orders['user_id']."','".$orders['grandtotal']."')");
			
			return $insert->affectedRows();
		}
}

?>