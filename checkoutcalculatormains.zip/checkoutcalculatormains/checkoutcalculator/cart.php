<?php
include("user.php");
include("header.php");


if($_POST)
{
	/*Save the prod into cart table*/

	$prod_id = $_POST['prodid'];
	$proditems = User::getProducts_details($prod_id);
	$productsincart  = array(
		'user_id'=>1,
		'prod_id'=>$proditems['id'],
		'prod_qty'=>1
		
	);
	
 $getcartdetail = User::getcartdetail_id($prod_id); 

 $cartprodid = $getcartdetail['prod_id'];
		
	if($_POST['prodid']!=$cartprodid)
	{
	$cart = User::Savecartitems($productsincart);
	}else{
		 $message = "Please update the quantity of the product, the product has been already added to the cart";
	}
}
	$getcartdetail = User::getcartdetail(1); 
	$grandtotal =0;
	$subtotal =0;
	$totalqty=0;
	foreach($getcartdetail as $cartval)
	{
		$cartprodid = $cartval['prod_id'];
		$grandtotal += $cartval['price'];
		$subtotal   += $cartval['price'];
		$totalqty   +=$cartval['prod_qty'];
	}
 


?>
<script>
$(document).ready(function(){
$("#update").click(function(){
  
  var userid = 1;
  var proqty_1    = $('#proqty_1').val();
  var proqty_2    = $('#proqty_2').val();
  var proqty_3    = $('#proqty_3').val();
  var proqty_4    = $('#proqty_4').val();
  
  var prod_1    = $('#prod_1').val();
  var prod_2    = $('#prod_2').val();
  var prod_3    = $('#prod_3').val();
  var prod_4    = $('#prod_4').val();
  
  var urlData = "proqty_1="+proqty_1+"&proqty_2="+proqty_2+"&proqty_3="+proqty_3+"&proqty_4="+proqty_4+"&prod_1="+prod_1+"&prod_2="+prod_2+"&prod_3="+prod_3+"&prod_4="+prod_4;
  
	$.ajax({
		url: '<?php BASE_URL; ?>update.php',
		data: urlData,
		type: "post",
		dataType: "json",
		async: true,
		success: function (data)
                {
					alert(data);
                }
		});

	});
});
</script>
<!-- PAGE BAR STARTS -->
<div class="page-bar">
    <div class="container">
        <div class="section-title">
            <h4>Cart</h4>
			<p><?php if(isset($message))echo $message;?>
        </div>
    </div>
</div>
<!-- PAGE BAR ENDS -->

<!-- CART TABLE STARTS -->

<section class="section-spacing">
    <div class="container">

        <div class="product-cart-count">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th class="cart-table-title" scope="col">Sr.No.</th>
                            <th class="cart-table-title" scope="col">Product Name</th>
                           
                            <th class="cart-table-title" scope="col">Quantity</th>
                            <th class="cart-table-title" scope="col">Price</th>
                            
                        </tr>
                    </thead>
                    <tbody>
					<?php
										
					foreach($getcartdetail as $key=>$cartitems)
					{ 
					
					?>
                        <tr>
                            <th scope="row"><?php echo $key+1;?></th>
                            <td>
                                <div class="cart-prod-title">
                                    <h6 ><?php echo $cartitems['prod_name'];?></h6>
                                </div>
                            </td>
                          
                            <td>
                                <div class="cart-qty">
                                    <input type="numeric" id="proqty_<?php echo $cartitems['prod_id'];?>"  name="proqty" value="<?php echo $cartitems['prod_qty'];?>" class="">
                                        
                                </div>
                            </td>
                            <td>
                                <div class="cart-price">
                                    <h5><?php echo $cartitems['price'];?></h5>
                                </div>
                            </td>
                            <input type="hidden" name="prodidval" id="prod_<?php echo $cartitems['prod_id'];?>" value="<?php echo $cartitems['prod_id'].'_'.$cartitems['prod_name'].'_'.$cartitems['price'];?>">
							
                        </tr>
					<?php } ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="cart-action-buttons">
            <div class="d-grid gap-2 d-md-block ms-auto">
				
				<button id="update" class="btn btn-primary brand-btn-black-outline" type="button">Update Cart</button>
                
            </div>
        </div>
		
    </div>
</section>

<!-- CART TABLE ENDS -->

<!-- CART SECTION TWO STARTS -->

<section class="section-spacing">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="section-title">
                    <h4>Cart total</h4>
                </div>
				<form method="post" action="<?php BASE_URL;?>checkout.php" >
                <div class="cart-total-wrapper">
                    <div class="table-responsive">
                        <table class="table">
                            <table class="table">
                                <tbody>
                                    <tr>
                                        <td class="cart-structure-name">Subtotal</td>
                                        <td>
                                            <div class="cart-price">
                                                <h5><?php echo $subtotal; ?></h5>
                                            </div>
                                        </td>
                                    </tr>
                                    
                                    <tr>
                                        <td class="cart-structure-name">Grand Total</td>
                                        <td>
                                            <div class="cart-price">
                                                <h5><?php echo $grandtotal; ?></h5>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </table>
                    </div>
                </div>
				<input type="hidden" name="prodid" value="<?php echo $prod_id;?>">
				<input type="hidden" name="prodqty" value="<?php echo $totalqty;?>">
				<input type="hidden" name="userid" value="1">
				
				<input type="hidden" name="grandtotal" value="<?php echo $grandtotal;?>">
                <div class="checkout-btn">
                    <button class="btn btn-primary brand-btn-black">Proceed to checkout</button>
                </div>
				</form>
            </div>
            
        </div>
    </div>
</section>

<!-- CART SECTION TWO ENDS -->

<!-- NO PRODUCT ADDED MESSAGE STARTS -->

<!-- NO PRODUCT ADDED MESSAGE ENDS -->

<!-- Footer section  -->
<?php include("footer.php") ?>