<?php 
if($_POST)
{
	
    $proqty_1 = $_POST['proqty_1'] ;
    $proqty_2 = $_POST['proqty_2'] ;
    $proqty_3 = $_POST['proqty_3'] ;
    $proqty_4 = $_POST['proqty_4'] ;
    
	

	$prodslist_1 = explode('_',$_POST['prod_1']);
	$prod_id_1    = $prodslist_1[0];
	$prod_name_1  = $prodslist_1[1];
	$prod_price_1 = $prodslist_1[2];
	
	$prodslist_2 = explode('_',$_POST['prod_2']);
	$prod_id_2    = $prodslist_2[0];
	$prod_name_2  = $prodslist_2[1];
	$prod_price_2 = $prodslist_2[2];
	
	$prodslist_3 = explode('_',$_POST['prod_3']);
	$prod_id_3    = $prodslist_3[0];
	$prod_name_3  = $prodslist_3[1];
	$prod_price_3 = $prodslist_3[2];
	
	$prodslist_4 = explode('_',$_POST['prod_4']);
	$prod_id_4    = $prodslist_4[0];
	$prod_name_4  = $prodslist_4[1];
	$prod_price_4 = $prodslist_4[2];
	$returnprice =0;
	
	if($prod_id_1!='' && $proqty_1==3)
	{
		$returnprice ='30_'; 
	}else if($prod_id_2!='' && $proqty_2==2)
	{
		$returnprice.='45_'; 
	}
	else if($prod_id_3!='' && $proqty_3==2)
	{
		$returnprice.='38_'; 
	}
	else if($prod_id_3!='' && $proqty_3==3)
	{
		$returnprice.='50_';
	}
	else if($prod_id_4!='' && $proqty_4==1)
	{
		$returnprice.='15_';
	}
	else if($prod_id_4!='' && $proqty_4==2 && $prod_id_1!='')
	{
		$returnprice.='5';
	}
	echo $returnprice;
	

}

?>