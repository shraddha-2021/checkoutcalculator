<?php
include("user.php");
include("header.php");
// PHP goes here!
$getProducts = User::getProducts();

?>

<!-- HOME CAROUSEL STARTS -->


<!-- HOME CAROUSEL ENDS -->

<!-- HOME PAGE SECTION ONE STARTS -->

<section class="section-spacing">
    <div class="container">
        <div class="section-tagline text-center">
        </div>
        <div class="section-title text-center">
            <h4>Products- Special offers on each products</h4>
        </div>

        <div class="carousel-wrapper mt-5">
            <div id="latest-products-carousel" class="owl-carousel owl-theme">
			<?php foreach($getProducts as $proditems){
				/*$offers = User ::getProductandoffers_details($proditems['id']); 
				
				foreach($offers as $sp_offer)
				{
					print('<pre>');
					print_r($offers);
				}*/
				?>
				<div class="item">
                    <div class="prod-wrapper">
                        <a href="<?php BASE_URL ; ?>product/<?php echo $proditems['id'];?>">
                            <img src="assets/images/<?php echo $proditems['img_name'];?>">
                        </a>
                    </div>

                    <div class="prod-detail">
                        <h4>
                            <a href="<?php BASE_URL ; ?>product.php/<?php echo $proditems['id'];?>"><?php echo $proditems['prod_name'];?></a>
                        </h4>
                    </div>

                    <div class="home-prod-price text-center">
                        <span class="amount"><?php echo $proditems['price'];?></span><br/>
                        <span class="sale-amount">Stock Available <?php echo $proditems['stock'];?></span><br/>
						
                    </div>
                    <div class="text-center mt-3">
					<form method="post" action="<?php BASE_URL;?>cart.php">

						<input type="hidden" name="prodid" value="<?php echo $proditems['id'];?>"/>
                       <input type="submit" name="submit" value="Add to Cart">
					 </form>
                    </div>
                </div>
			<?php } ?>
                
			

            </div>
        </div>
    </div>
</section>

    <!-- HOME PAGE SECTION SEVEN ENDS -->

    <!-- Footer section  -->
    <?php include("footer.php") ?>