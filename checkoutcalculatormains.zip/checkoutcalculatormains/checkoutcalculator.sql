-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 29, 2022 at 05:48 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.3.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `checkoutcalculator`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `prod_id` int(11) NOT NULL,
  `prod_qty` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `flag` int(11) NOT NULL,
  `lastupdated` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `user_id`, `prod_id`, `prod_qty`, `status`, `flag`, `lastupdated`) VALUES
(2, 1, 2, 1, 0, 0, '2022-03-29 18:40:45'),
(3, 1, 1, 1, 0, 0, '2022-03-29 19:30:59'),
(6, 1, 3, 1, 0, 0, '2022-03-29 20:09:46'),
(7, 1, 4, 1, 0, 0, '2022-03-29 20:10:19');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `prodid` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `prodqty` int(11) NOT NULL,
  `grandtotal` int(11) NOT NULL,
  `lastupdated` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `prodid`, `user_id`, `prodqty`, `grandtotal`, `lastupdated`) VALUES
(1, 0, 1, 0, 50, '2022-03-29 19:29:30'),
(2, 0, 1, 2, 50, '2022-03-29 19:30:44'),
(3, 1, 1, 3, 100, '2022-03-29 19:31:06');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `prod_name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `price` double NOT NULL,
  `special_price` double NOT NULL,
  `stock` int(11) NOT NULL,
  `img_name` varchar(255) NOT NULL,
  `skuno` varchar(255) NOT NULL,
  `prod_type` varchar(100) NOT NULL,
  `publish_date` datetime NOT NULL DEFAULT current_timestamp(),
  `lastupdate_date` datetime NOT NULL DEFAULT current_timestamp(),
  `status` int(11) NOT NULL,
  `flag` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `prod_name`, `description`, `price`, `special_price`, `stock`, `img_name`, `skuno`, `prod_type`, `publish_date`, `lastupdate_date`, `status`, `flag`) VALUES
(1, 'A', 'Product A is red in color', 50, 50, 100, 'product-1.png', 'AAAAA', '1', '2022-03-29 06:31:01', '2022-03-29 06:31:01', 0, 0),
(2, 'B', 'Product B is yellow in color', 30, 30, 100, 'product-2.png', 'BBBBB', '2', '2022-03-29 06:31:21', '2022-03-29 06:31:21', 0, 0),
(3, 'C', 'Product C is Blue in color', 20, 20, 100, 'product-3.png', 'CCCCC', '3', '2022-03-29 06:31:21', '2022-03-29 06:31:21', 0, 0),
(4, 'D', 'Product D is White in color', 15, 15, 100, 'product-4.png', 'DDDDD', '4', '2022-03-29 06:31:21', '2022-03-29 06:31:21', 0, 0),
(5, 'E', 'Product E is Brown in color', 5, 5, 100, 'product-5.png', 'EEEEE', '4', '2022-03-29 06:31:21', '2022-03-29 06:31:21', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `product_sp_offer`
--

CREATE TABLE `product_sp_offer` (
  `id` int(11) NOT NULL,
  `prod_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `sp_price` int(11) NOT NULL,
  `publish_date` datetime NOT NULL DEFAULT current_timestamp(),
  `status` int(11) NOT NULL,
  `flag` int(11) NOT NULL,
  `lastupdated_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_sp_offer`
--

INSERT INTO `product_sp_offer` (`id`, `prod_id`, `quantity`, `sp_price`, `publish_date`, `status`, `flag`, `lastupdated_date`) VALUES
(1, 1, 3, 130, '2022-03-29 06:36:09', 0, 0, '2022-03-29 06:36:09'),
(2, 2, 2, 45, '2022-03-29 06:36:31', 0, 0, '2022-03-29 06:36:31'),
(3, 3, 2, 38, '2022-03-29 06:36:31', 0, 0, '2022-03-29 06:36:31'),
(4, 3, 3, 50, '2022-03-29 06:36:31', 0, 0, '2022-03-29 06:36:31'),
(5, 4, 1, 15, '2022-03-29 06:36:31', 0, 0, '2022-03-29 06:36:31');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_sp_offer`
--
ALTER TABLE `product_sp_offer`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `product_sp_offer`
--
ALTER TABLE `product_sp_offer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
