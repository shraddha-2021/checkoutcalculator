<?php
include("user.php");
include("header.php");
// PHP goes here!
$getProducts = User::getProducts();

?>

<!-- HOME CAROUSEL STARTS -->


<!-- HOME CAROUSEL ENDS -->

<!-- HOME PAGE SECTION ONE STARTS -->

<section class="section-spacing">
    <div class="container">
        <div class="section-tagline text-center">
        </div>
        <div class="section-title text-center">
            <h4>Products- Special offers on each products</h4>
        </div>

        <div class="carousel-wrapper mt-5">
            <div id="latest-products-carousel" class="owl-carousel owl-theme">
			<?php foreach($getProducts as $key=>$value){
				
				?>
				<form method="post" action="<?php BASE_URL;?>cart.php">
				<div class="item">
                    <div class="prod-wrapper">
                        <a href="<?php BASE_URL ; ?>product/<?php echo $getProducts[$key]['id'];?>">
                            <img src="assets/images/<?php echo $getProducts[$key]['img_name'];?>">
                        </a>
                    </div>

                    <div class="prod-detail">
                        <h4>
                            <a href="<?php BASE_URL ; ?>product.php/<?php echo $getProducts[$key]['id'];?>"><?php echo $getProducts[$key]['prod_name'];?></a>
                        </h4>
                    </div>

                    <div class="home-prod-price text-center">
						 <input type="text" maxlength="2" name="quantity" value="1"
                        size="4" class="input-cart-quantity" />
						<input type="image" src="add-to-cart.png" class="btnAddAction" />
                        <span class="amount"><?php echo $getProducts[$key]['price'];?></span><br/>
                        <span class="sale-amount">Stock Available <?php echo $getProducts[$key]['stock'];?></span><br/>
						
                    </div>
                    <div class="text-center mt-3">
						<input type="hidden" name="prodid" value="<?php echo $getProducts[$key]['id'];?>"/>
						<input type="hidden" name="prodcode" value="<?php echo $getProducts[$key]['prod_code'];?>"/>

					 </form>
                    </div>
                </div>
			<?php } ?>
                
			

            </div>
        </div>
    </div>
</section>

    <!-- HOME PAGE SECTION SEVEN ENDS -->

    <!-- Footer section  -->
    <?php include("footer.php") ?>