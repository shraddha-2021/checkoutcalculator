<?php 
$user_id=1;
$itemcount=0;
$getcartdetailitems = User::getcartandproddetail($user_id); 
foreach($getcartdetailitems as $key=> $cartval)
	{
		$itemcount = $key+1;
	}

?>
<!DOCTYPE html>
<html>

<head>
    <title>
       Checkout
    </title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="assets/css/normalize.css">

    <!-- Iconfont Link -->
    <link rel="stylesheet" href="assets/icofont/icofont.min.css" />
    <!-- JQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">

    <!-- Bootstrap JS -->
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>

    <!-- Cosma Stylesheet -->
    <link rel="stylesheet" href="assets/css/cosma-styles.css" />
    <link rel="stylesheet" href="assets/css/responsive.css" />

    <!-- Font Styles -->
    <link rel="stylesheet" href="assets/css/fonts.css" />



    <!-- Owl carousel -->
    <link rel="stylesheet" href="assets/owl-carousel/dist/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/owl-carousel/dist/assets/owl.theme.default.min.css">
    <script src="assets/owl-carousel/dist/owl.carousel.min.js"></script>

    <!-- Local Script -->
    <script src="assets/js/main.js"></script>
</head>

<body>
    <header>
        <!-- contact content -->
        <!-- <div class="header-content-top">
            <div class="content">
                <span><i class="fas fa-phone-square-alt"></i> (00)0000-0000</span>
                <span><i class="fas fa-envelope-square"></i>email@email.com.br</span>
            </div>
        </div> -->
        <!-- / contact content -->
        <div class="header-container">
            <!-- logo -->
            
            <!-- open nav mobile -->

            <!--search -->
            <label class="open-search" for="open-search">
                <i class="icofont-search"></i>
                <input class="input-open-search" id="open-search" type="checkbox" name="menu" />
                <div class="search">
                    <button class="button-search"><i class="icofont-search"></i></button>
                    <input type="text" placeholder="What are you looking for?" class="input-search" />
                </div>
            </label>
            <!-- // search -->
            <nav class="nav-content">
                <!-- nav -->
                <ul class="nav-content-list">
                   
                <li class="nav-content-item"><a class="nav-content-link" href="cart.php"><i class="icofont-cart"></i><?php echo $itemcount;?></a></li>
               
                <!-- call to action -->
                </ul>
            </nav>
        </div>
        <!-- nav navigation commerce -->
       
    </header>
</body>

</html>