<?php
include('database.php');
class User{
	
	    

	 public static function getProducts(){
			$db     = new Db();
			$prodlist = $db->query('SELECT * FROM products')->fetchAll(); 
			return $prodlist;
		}
		
		
		 public static function getProducts_details($prodid){
			
			$db     = new Db();
			$prodlist = $db->query('SELECT * FROM products WHERE id='.$prodid.'')->fetchArray(); 
			return $prodlist;
		}
		public static function getProducts_bycode($prodcode){
			$db     = new Db();
			$prodlist = $db->query('SELECT * FROM products WHERE prod_code="'.$prodcode.'"')->fetchArray(); 
			return $prodlist;
		}
		 public static function getProducts_array($prodid){
			$db     = new Db();
			$prodlist = $db->query('SELECT * FROM products WHERE id='.$prodid[0].'')->fetchArray(); 
			return $prodlist;
		}
		public static function getcartandproddetail($userid){
			$db     = new Db();
			$prodlist = $db->query('SELECT products.*,cart.*,cart.id as cart_id FROM cart LEFT JOIN products ON products.id=cart.prod_id WHERE cart.user_id='.$userid.'')->fetchAll(); 
			return $prodlist;
		}
		
		public static function getcartdetail($prod_id,$userid){
			
			$db     = new Db();
			$prodlist = $db->query('SELECT * FROM cart WHERE prod_id='.$prod_id.' AND user_id='.$userid.'')->fetchArray(); 
			return $prodlist;
		}
		
		public static function getcartdetailbyid($userid){
			$db     = new Db();
			$prodlist = $db->query('SELECT * FROM cart WHERE user_id='.$userid.'')->fetchAll(); 
			return $prodlist;
		}
		
		public static function Savecartitems($productsincart)
		{ 	
			$db     = new Db();
			
			$insert = $db->query("INSERT INTO cart(prod_id,prod_qty,user_id,totalprice) VALUES ('".$productsincart['prod_id']."','".$productsincart['prod_qty']."','".$productsincart['user_id']."','".$productsincart['totalprice']."')");
			
			return $insert->affectedRows();
		}
	
		public static function Saveorderitems($orders)
		{ 	
			$db     = new Db();
			
			$insert = $db->query("INSERT INTO orders(prodid,prodqty,user_id,grandtotal) VALUES ('".$orders['prodid']."','".$orders['prodqty']."','".$orders['user_id']."','".$orders['grandtotal']."')");
			
			return $insert->affectedRows();
		}
		
		public static function UpdateCartItems($newQuantity,$cartid,$prodid,$totalprice)
		{ 	
	
			$db     = new Db();
			$insert = $db->query("UPDATE cart set prod_qty=".$newQuantity.",totalprice=".$totalprice."  WHERE prod_id=".$prodid." AND id=".$cartid."");
			
			return $insert->affectedRows();
		}
		
		public static function updatenewqtytocart($newQuantity,$cartid)
		{ 	
			$db     = new Db();
			
			$insert = $db->query("UPDATE cart set prod_qty='".$newQuantity."'  WHERE  id= '".$cartid."'");
			
			//return $insert->affectedRows();
		}
		public static function getspecialofferprice($prodid)
		{ 	
			$db     = new Db();
			$prodlist = $db->query('SELECT * FROM product_sp_offer WHERE prod_id='.$prodid.'')->fetchAll(); 
			return $prodlist;
		}
		
		public static function getprodandofferdetail($prodid)
		{ 
			$db     = new Db();
			
			$prodlist = $db->query('SELECT products.*,product_sp_offer.* FROM product_sp_offer LEFT JOIN products ON products.id=product_sp_offer.prod_id WHERE products.id='.$prodid.' AND product_sp_offer.id='.$prodid.'')->fetchAll();
					
			return $prodlist;
			
		}
		public static function getcartqty($prod_id,$userid){
			
			$db     = new Db();
			$prodlist = $db->query('SELECT sum(prod_qty) as cartprodqty FROM cart WHERE prod_id='.$prod_id.' AND user_id='.$userid.'')->fetchArray(); 
			return $prodlist;
		}
		public static function calculateprice($offerdetails,$quantity,$prod_id)
		{
			
			foreach($offerdetails as $off){

			$totalprice=0;
			if($quantity<$off['quantity']){
				$singleunit=$off['quantity']-$quantity;
				$totalprice=$off['main_price']*$quantity;
				
				//echo $quantity.'=>'.$singleunit.'=>>'.$totalprice;
				
			}else{
				$multipleunit=$quantity-$off['quantity'];
				
				$totalqty = $quantity+$multipleunit;
				
				$multiprice = $off['sp_price'];
				$multimodprice= $multipleunit*$off['main_price'];
				
				$totalprice = $multiprice+$multimodprice;
				
				//echo $quantity.'=>'.$multipleunit.'=>>'.$totalqty.'<br/>';
				//echo $multiprice.'=>!!'.$multimodprice.'=>>!!'.$totalprice.'<br/>';
			}
			
			}
			return  $totalprice;
		}
}

?>