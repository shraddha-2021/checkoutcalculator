<?php
include("user.php");
include("header.php");
// PHP goes here!
if($_POST)
{
	$prodid		= $_POST['prodid'];
	$prodqty	= $_POST['prodqty'];
	$user_id 	= $_POST['userid'];
	$grandtotal = $_POST['grandtotal'];

	$orderarray = array(
		"prodid"     =>$prodid,
		"prodqty"    =>$prodqty,
		"user_id"    =>$user_id,
		"grandtotal" =>$grandtotal
	);
	
	$rtn = User::Saveorderitems($orderarray);
	

	$successmsg = "Your order has been successfully place";
}
?>

<!-- PAGE BAR STARTS -->
<div class="page-bar">
    <div class="container">
        <div class="section-title">
            <h4>Checkout</h4>
        </div>
		<p><?php if(isset($successmsg)) echo $successmsg; </p>
    </div>
</div>
<!-- PAGE BAR ENDS -->

<!-- CHECKOUT SECTION STARTS -->

<section class="section-spacing">
    
</section>

<!-- CHECKOUT SECTION ENDS -->

<!-- Footer section  -->
<?php include("footer.php") ?>