<?php
include("user.php");
include("header.php");

$user_id  = 1;
if($_POST)
{

	$prod_id  = $_POST['prodid'];
	$prodcode = $_POST['prodcode'];
	$quantity = $_POST['quantity'];

	
	/*Get product details by code */
	$proditems = User::getProducts_bycode($prodcode);

	/*Get Cart details by product*/
	$getcartdetail = User::getcartdetail($proditems['id'],$user_id); 

	/*Save array Products into Cart*/
		
	if (!empty($getcartdetail)) {
		// Update quantity into car table
		$newQuantity       = $getcartdetail["prod_qty"] + $_POST["quantity"];
		
		// Add to cart table
		
		$offerdetails = User::getspecialofferprice($prod_id);
		
		if(!empty($offerdetails))
		{
			$totalprice= User ::calculateprice($offerdetails,$newQuantity,$prod_id);
		}
		$updatecartdetails = User::UpdateCartItems($newQuantity,$getcartdetail["id"],$getcartdetail["prod_id"],$totalprice);
		 $message = "Your product quantity has been updated into cart";
		
	} else {
			
		// Add to cart table
		
		$offerdetails = User::getspecialofferprice($prod_id);
		
		if(!empty($offerdetails))
		{
			$totalprice= User ::calculateprice($offerdetails,$quantity,$prod_id);
		}
		/*Save array*/
		$productsincart  = array(
		'user_id'=>$user_id,
		'prod_id'=>$proditems['id'],
		'prod_qty'=>$quantity,
		'totalprice'=>$totalprice
		);
		 $addcartdetails = User::Savecartitems($productsincart);
		 $message = "Your product has been added to cart";
	}
				

}
	$getcartdetailitems = User::getcartandproddetail($user_id); 
	$grandtotal =0;
	$subtotal =0;
	$totalqty=0;
	$tprice =0;
	$cartprodid='';
	foreach($getcartdetailitems as $key=> $cartval)
	{
		$key = $key+1;
		$cartprodid = $cartval['prod_id'];
		
		$totalqty   +=$cartval['prod_qty'];
		$tprice     +=$cartval['totalprice'];
		$grandtotal = $tprice;
		$subtotal   = $tprice;
		$itemcount  = $key+1;
	}
	
	
	/*$getofferdetails = User::getprodandofferdetail($cartprodid); 
	foreach($getofferdetails as $key=>$offitems)
	{
		$cartqty =User::getcartqty($offitems['id'],$user_id);
		$rqty =abs($cartqty['cartprodqty']-$quantity);
		echo $rqty;
		if($rqty<=0){
			
			$total_price1 +=$cartqty['cartprodqty']*$offitems['prod_price'];
			$total_price1 +=abs($rqty)*$offitems['price'];
			echo $total_price1;
		}else{
			$total_price1 =$quantity*$offitems['prod_price'];
		}
	}
	if(isset($total_price1) && trim($total_price1)!='')
	  {
	  $total_price=$total_price1;
	  }
	echo $total_price;
	
*/
?>
<script>

function plus_quantity(cart_id, price,prod_id) {
    var qtyt = $("#inputqty-"+cart_id);
    var newQuantity = parseInt($(qtyt).val())+1;
    var newPrice = newQuantity * price;
	var pid = $("#prod_"+prod_id);
    savecart(cart_id, newQuantity, newPrice,prod_id);
}

function minus_quantity(cart_id, price,prod_id) {
    var qtyt = $("#inputqty-"+cart_id);
    if($(qtyt).val() > 1) 
    {
    var newQuantity = parseInt($(qtyt).val()) - 1;
    var newPrice = newQuantity * price;
	var pid = $("#prod_"+prod_id);


    savecart(cart_id, newQuantity, newPrice,prod_id);
    }
}

function savecart(cart_id, new_quantity, newPrice,prod_id) {
	var qtyt = $("#inputqty-"+cart_id);
	
	var priceElement = $("#cart-price-"+cart_id);
    $.ajax({
		url : "update.php",
		data : "cart_id="+cart_id+"&new_quantity="+new_quantity+"&prod_id="+prod_id,
		type : 'post',
		success : function(response) {
			
			$(qtyt).val(new_quantity);
            $(priceElement).text("$"+newPrice);
            var totalQuantity = 0;
            $("input[id*='inputqty-']").each(function() {
                var cart_quantity = $(this).val();
                totalQuantity = parseInt(totalQuantity) + parseInt(cart_quantity);
            });
            $("#total-quantity").text(totalQuantity);
            var totalItemPrice = 0;
            $("div[id*='cart-price-']").each(function() {
                var cart_price = $(this).text().replace("$","");
                totalItemPrice = parseInt(totalItemPrice) + parseInt(cart_price);
            });
            $("#total-price").text(totalItemPrice);
			window.location.reload(true);
			
		}
	});
}
</script>
<!-- PAGE BAR STARTS -->
<div class="page-bar">
    <div class="container">
        <div class="section-title">
            <h4>Cart</h4>
			<p><?php if(isset($message))echo $message;?>
        </div>
    </div>
</div>
<!-- PAGE BAR ENDS -->

<!-- CART TABLE STARTS -->

<section class="section-spacing">
    <div class="container">

        <div class="product-cart-count">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th class="cart-table-title" scope="col">Sr.No.</th>
                            <th class="cart-table-title" scope="col">Product Name</th>
                           <th class="cart-table-title" scope="col">Quantity</th>
						    <th class="cart-table-title" scope="col">Unit</th>
                            <th class="cart-table-title" scope="col">Price</th>
                            
                        </tr>
                    </thead>
                    <tbody>
					<?php
										
					foreach($getcartdetailitems as $key=>$cartitems)
					{ 
				
					?>
                        <tr>
                            <th scope="row"><?php echo $key+1;?></th>
                            <td>
                                <div class="cart-prod-title">
                                    <h6 ><?php echo $cartitems['prod_name'];?></h6>
                                </div>
                            </td>
                          
                            <td>
							<div class="cart-qty">
									<div class="btn-increment-decrement"  onClick="minus_quantity(<?php echo $cartitems["cart_id"]; ?>, '<?php echo $cartitems["price"]; ?>','<?php echo $cartitems['prod_id'];?>')">-</div>
                                    <input type="numeric" id="inputqty-<?php echo $cartitems['cart_id'];?>"  name="proqty" value="<?php echo $cartitems['prod_qty'];?>">
									<div class="btn-increment-decrement" 
									onClick="plus_quantity(<?php echo $cartitems["cart_id"]; ?>, '<?php echo $cartitems["price"]; ?>','<?php echo $cartitems['prod_id'];?>')">+</div>
                                        
                                </div>
                            </td>
							<td>
                                <div class="cart-qty" >
                                    <h5><?php echo $cartitems['price']; ?></h5>
                                </div>
                            </td>
                            <td>
                             <div class="cart-price-<?php echo $cartitems["cart_id"]; ?>" id="cart-price-<?php echo $item["cart_id"]; ?>">
                                    <?php echo "$".($cartitems['totalprice']); ?>
                                </div>
                            </td>
                            <input type="hidden" name="prodidval" id="prod_<?php echo $cartitems['prod_id'];?>" value="<?php echo $cartitems['prod_id'];?>">
							<input type="hidden" name="prodcount" id="prodcount" value="<?php echo $itemcount; ?>">
							
                        </tr>
					<?php } ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</section>

<!-- CART TABLE ENDS -->

<!-- CART SECTION TWO STARTS -->

<section class="section-spacing">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="section-title">
                    <h4>Cart total</h4>
                </div>
				<form method="post" action="<?php BASE_URL;?>checkout.php" >
                <div class="cart-total-wrapper">
                    <div class="table-responsive">
                        <table class="table">
                            <table class="table">
                                <tbody>
                                    <tr>
                                        <td class="cart-structure-name">Subtotal</td>
                                        <td>
                                            <div class="cart-price">
                                                <h5 id="total-price"><?php echo $subtotal; ?></h5>
                                            </div>
                                        </td>
                                    </tr>
                                    
                                    <tr>
                                        <td class="cart-structure-name">Grand Total</td>
                                        <td>
                                            <div class="cart-price">
                                                <h5 id="total-price"><?php echo $grandtotal; ?></h5>
                                            </div>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </table>
                    </div>
                </div>
				<input type="hidden" name="prodid" value="<?php echo $prod_id;?>">
				<input type="hidden" name="prodqty" value="<?php echo $totalqty;?>">
				<input type="hidden" name="userid" value="1">
				
				<input type="hidden" name="grandtotal" value="<?php echo $grandtotal;?>">
                <div class="checkout-btn">
                    <button class="btn btn-primary brand-btn-black">Proceed to checkout</button>
                </div>
				</form>
            </div>
            
        </div>
    </div>
</section>

<!-- CART SECTION TWO ENDS -->

<!-- NO PRODUCT ADDED MESSAGE STARTS -->

<!-- NO PRODUCT ADDED MESSAGE ENDS -->

<!-- Footer section  -->
<?php include("footer.php") ?>