<footer>
   <div class="footer-two">
        <div class="container">
            <ul class="footer-two-list">
                <li><a href="about-us.php"><p>About Us</p></a></li>
                <li><a href="terms-conditions.php"><p>Terms & Condition</p></a></li>
                <li><a href="contact-us.php"><p>Contact Us</p></a></li>
                <li><a href="faq.php"><p>FAQ</p></a></li>
            </ul>
        </div>
    </div>
</footer>