<?php
include("user.php");
$prod_id     = $_POST["prod_id"];
$card_id	 = $_POST["cart_id"];
$newQuantity = $_POST["new_quantity"];


$offerdetails = User::getspecialofferprice($prod_id);
$totalprice =0;
if(!empty($offerdetails))
{
	$totalprice= User ::calculateprice($offerdetails,$newQuantity,$prod_id);
	

}

$updatecartdetails = User::UpdateCartItems($newQuantity,$card_id,$prod_id,$totalprice);
 //$updateid = User :: updatenewqtytocart($_POST["new_quantity"], $_POST["cart_id"]);


?>